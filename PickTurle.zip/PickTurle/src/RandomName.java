import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class RandomName {
    String[] all={"刘瑾灏","陈锦尉","徐浩棚","吴扬昊","周志杨","肖博文","黄梓洋","张第航","黄思雨","宋坤骏","贺逸轩",
            "曾俊杰","刘美灵","张义鸿","巨依琳",
            "任艳霞",
            "杨程","阳沚含","卞泽敏","向侯丞","杜朋呈",
            "赵雅伊","郭翔宇","潘柳岑","张莞淇","蒲鹏宇","李佳蓉","夏常洲","陈宇航","朱稼棋",
            "吴其右",
            "陈伦辛","戴文艺","李大铭","黎伦旗","张鑫","王露雪","田峻荣","彭蓉","余成棣","曾心竹",
            //"周文浩",
            "刘昊羽","李璨宇","步梓豪","侯雅妮",

            "齐思源",

            "马佳璐","薛槟彤","胡罗彧涵","邹怀锋",
            "朱瑞",
            "杨伟艺",
            "涂柘岍"};

    String getRandom(){
        int random=(int) (Math.random()*all.length);
        return all[random];
    }
    int getTimes(){
        return (int) (Math.random()*15)+6;
    }

    public static void main(String[] args) throws ClassNotFoundException, UnsupportedLookAndFeelException, InstantiationException, IllegalAccessException {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        new RandomName().build();

    }
    ArrayList<Font> fonts=new ArrayList<>();
    int min=70;
    int max=100;
    void buildFonts(){
        int size;
        for(size=max;size>min;size--){
            fonts.add(new Font("等线",Font.PLAIN,size));
        }
    }
    Thread currentThread;
    void build(){
        //event.add(Event.Info,"!!!",verify().toString(),true);
        buildFonts();
        init();
        JDialog booter=new JDialog();
        booter.setUndecorated(true);
        booter.getContentPane().setBackground(Color.GRAY);
        JButton exec=new JButton("抽一王八");
        exec.setFont(new Font("等线",Font.PLAIN,20));
        exec.addActionListener(e -> {
            if(currentThread!=null){
                currentThread.stop();
            }
            main.setVisible(false);
            currentThread=new Thread(this::buildGUI);
            currentThread.start();
        });
        exec.setBackground(Color.GRAY);
        booter.getContentPane().add(exec);
        booter.pack();
        Dimension size=booter.getSize();
        booter.setLocation(1366-size.width,768-50-size.height);
        booter.setSize(size);
        booter.setAlwaysOnTop(true);


        booter.setVisible(true);
    }
    Font normalF=new Font("等线",Font.PLAIN,min);
    JFrame main=new JFrame();
    JLabel name=new JLabel();
    void init(){
        name.setBackground(Color.gray);
        name.setFont(normalF);
        Box box=Box.createHorizontalBox();
        box.add(Box.createHorizontalGlue());
        box.add(name);
        box.add(Box.createHorizontalGlue());
        main.setUndecorated(true);
        main.setBackground(Color.GRAY);
        main.setAlwaysOnTop(true);
        main.setSize(600,400);
        main.setLocationRelativeTo(null);
        box.setBackground(Color.GRAY);
        main.add(box);

        JButton close=new JButton("Close");
        close.addActionListener((e)->main.setVisible(false));
        close.setFont(new Font("等线",Font.PLAIN,19));
        main.add(close,BorderLayout.SOUTH);
    }
    void buildGUI(){
        main.setVisible(true);
        name.setForeground(Color.black);
        int times=getTimes();
        try {
            for (int i = 0; i < times; i++) {
                name.setText(getRandom());
                animation(name);
            }
/*            name.setText("宏宏");
            animation(name);*/
        }catch (InterruptedException ignored){

        }

        name.setForeground(Color.RED);
    }
    Map<String,Integer> verify(){
        Map<String,Integer> p=new HashMap<>();
        for(String i:all){
            p.put(i,0);
        }
        for(int i=0;i<100000000;i++){
            String name=getRandom();
            p.put(name,p.get(name)+1);
        }
        return p;
    }
    void animation(JLabel jLabel) throws InterruptedException {
                for(Font i:fonts){
                    jLabel.setFont(i);
                    Thread.sleep(4);
                }
    }
}
